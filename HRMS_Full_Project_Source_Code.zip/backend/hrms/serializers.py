from rest_framework import serializers
from .models import Department, Employee, Attendance, LeaveRequest, Payroll

class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = "__all__"

class EmployeeSerializer(serializers.ModelSerializer):
    department_name = serializers.CharField(source="department.name", read_only=True)
    class Meta:
        model = Employee
        fields = "__all__"

class AttendanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Attendance
        fields = "__all__"

class LeaveRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = LeaveRequest
        fields = "__all__"
        read_only_fields = ("status", "created_at")
    def validate(self, attrs):
        if attrs["to_date"] < attrs["from_date"]:
            raise serializers.ValidationError("To date must be on or after from date.")
        return attrs

class PayrollSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payroll
        fields = "__all__"
    def validate(self, attrs):
        expected = attrs["basic_salary"] + attrs["allowance"] - attrs["deduction"]
        if attrs["net_salary"] != expected:
            raise serializers.ValidationError("Net salary must equal basic salary + allowance - deduction.")
        return attrs
