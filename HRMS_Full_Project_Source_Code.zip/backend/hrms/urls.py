from rest_framework.routers import DefaultRouter
from .views import DepartmentViewSet, EmployeeViewSet, AttendanceViewSet, LeaveRequestViewSet, PayrollViewSet

router = DefaultRouter()
router.register("departments", DepartmentViewSet)
router.register("employees", EmployeeViewSet)
router.register("attendance", AttendanceViewSet)
router.register("leaves", LeaveRequestViewSet)
router.register("payroll", PayrollViewSet)

urlpatterns = router.urls
