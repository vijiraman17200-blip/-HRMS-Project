# HRMS Full Stack Project

Stack: React (Vite) + Django REST Framework + MySQL.

## 1. Prerequisites
- Python 3.10+
- Node.js LTS and npm
- MySQL Server / MySQL Workbench
- VS Code
- Git (optional)

## 2. Database
Run in MySQL Workbench:
```sql
CREATE DATABASE hrms_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

## 3. Backend setup (Windows)
```powershell
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```
Edit `config/settings.py` and set your local MySQL username/password.
```powershell
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```
Backend: http://127.0.0.1:8000/
API: http://127.0.0.1:8000/api/

## 4. Frontend setup
Open a second terminal:
```powershell
cd frontend
npm install
npm run dev
```
Frontend: http://localhost:5173/

## 5. Included features
- Dashboard summary
- Department CRUD
- Employee CRUD
- Attendance records
- Leave requests
- Payroll records

## 6. Important development note
This is a local learning starter. API access is open for local testing so the React pages work immediately. It is NOT safe for public deployment. Before deployment, add authentication, role-based permissions, per-employee data filtering, secure secrets, HTTPS, validation, audit logs and tests. Restrict payroll and employee personal information to authorized users.

## 7. Sample employee JSON
POST `/api/employees/`
```json
{
  "name": "Ananya Kumar",
  "email": "ananya@example.com",
  "phone": "9876543210",
  "department": 1,
  "designation": "Software Developer",
  "salary": "35000.00",
  "joining_date": "2026-11-16"
}
```

## 8. Build order
1. Start MySQL and create database.
2. Run backend migrations and test `/api/departments/`.
3. Add a department in the frontend.
4. Add an employee and confirm it appears in the list.
5. Test attendance, leave and payroll endpoints.
6. Add authentication and role permissions before sharing/deploying.
