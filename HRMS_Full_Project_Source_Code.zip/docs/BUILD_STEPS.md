# HRMS build steps

1. Install Python, Node.js and MySQL.
2. Create MySQL database `hrms_db`.
3. Configure the database password in `backend/config/settings.py`.
4. Create and activate the Python virtual environment.
5. Install backend requirements.
6. Run Django migrations and create a superuser.
7. Start Django on port 8000.
8. Install frontend dependencies and start Vite on port 5173.
9. Create a department first.
10. Add employees and test edit/delete.
11. Add attendance, leave and payroll data through Django admin or API.
12. Add secure login, roles and tests before production.

## Main API routes
- `/api/departments/`
- `/api/employees/`
- `/api/attendance/`
- `/api/leaves/`
- `/api/payroll/`

All routes support standard ModelViewSet CRUD operations.
