import { BrowserRouter, Routes, Route, NavLink } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import Employees from "./pages/Employees";
import Departments from "./pages/Departments";
import GenericModule from "./pages/GenericModule";

const links = [
  ["/", "Dashboard"], ["/employees", "Employees"], ["/departments", "Departments"],
  ["/attendance", "Attendance"], ["/leaves", "Leave"], ["/payroll", "Payroll"]
];

function Layout() {
  return <div className="app-shell">
    <aside className="sidebar">
      <h3 className="brand">HRMS</h3>
      <p className="small text-white-50">Human Resource System</p>
      {links.map(([to, label]) => <NavLink key={to} end={to === "/"} to={to} className={({isActive}) => "side-link " + (isActive ? "active" : "")}>{label}</NavLink>)}
    </aside>
    <main className="main-content">
      <div className="topbar"><span>Human Resource Management</span><span className="user-chip">Admin</span></div>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/employees" element={<Employees />} />
        <Route path="/departments" element={<Departments />} />
        <Route path="/attendance" element={<GenericModule endpoint="attendance" title="Attendance" />} />
        <Route path="/leaves" element={<GenericModule endpoint="leaves" title="Leave Requests" />} />
        <Route path="/payroll" element={<GenericModule endpoint="payroll" title="Payroll Records" />} />
      </Routes>
    </main>
  </div>;
}

export default function App() {
  return <BrowserRouter><Layout /></BrowserRouter>;
}
