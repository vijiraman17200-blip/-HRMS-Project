import { useEffect, useState } from "react";
import API from "../services/api";

export default function Departments() {
  const [rows,setRows] = useState([]);
  const [name,setName] = useState("");
  const [description,setDescription] = useState("");
  const [message,setMessage] = useState("");
  async function load(){ try{const r=await API.get("departments/");setRows(r.data);}catch{setMessage("Unable to load departments.");} }
  useEffect(()=>{load();},[]);
  async function add(e){e.preventDefault();try{await API.post("departments/",{name,description});setName("");setDescription("");setMessage("Department added.");load();}catch(err){setMessage(JSON.stringify(err.response?.data||"Add failed"));}}
  async function remove(id){if(!window.confirm("Delete department?"))return;try{await API.delete(`departments/${id}/`);load();}catch{setMessage("Delete failed. Department may still have employees.");}}
  return <div><h2 className="mb-3">Departments</h2>{message&&<div className="alert alert-info">{message}</div>}
    <form className="panel mb-4" onSubmit={add}><div className="row g-2"><div className="col-md-4"><input className="form-control" placeholder="Department name" value={name} onChange={e=>setName(e.target.value)} required /></div><div className="col-md-6"><input className="form-control" placeholder="Description" value={description} onChange={e=>setDescription(e.target.value)} /></div><div className="col-md-2"><button className="btn btn-primary w-100">Add</button></div></div></form>
    <div className="panel"><table className="table"><thead><tr><th>ID</th><th>Name</th><th>Description</th><th>Action</th></tr></thead><tbody>{rows.map(r=><tr key={r.id}><td>{r.id}</td><td>{r.name}</td><td>{r.description}</td><td><button className="btn btn-sm btn-danger" onClick={()=>remove(r.id)}>Delete</button></td></tr>)}</tbody></table></div>
  </div>;
}
