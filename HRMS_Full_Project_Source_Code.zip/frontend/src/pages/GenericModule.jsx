import { useEffect, useState } from "react";
import API from "../services/api";

export default function GenericModule({endpoint,title}) {
  const [rows,setRows]=useState([]);
  const [error,setError]=useState("");
  useEffect(()=>{API.get(`${endpoint}/`).then(r=>setRows(r.data)).catch(()=>setError("Could not load records."));},[endpoint]);
  return <div><h2 className="mb-3">{title}</h2>{error&&<div className="alert alert-warning">{error}</div>}
    <div className="panel"><p className="text-secondary">API connection preview. Create and review records using the API endpoints or Django admin. A dedicated form and approval workflow can be added as the next development phase.</p>
      <div className="badge text-bg-primary mb-2">{rows.length} records</div>
      <pre className="small bg-light p-3 rounded" style={{maxHeight:360,overflow:"auto"}}>{JSON.stringify(rows,null,2)}</pre>
    </div>
  </div>;
}
