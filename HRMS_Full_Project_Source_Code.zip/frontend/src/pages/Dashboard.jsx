import { useEffect, useState } from "react";
import API from "../services/api";

export default function Dashboard() {
  const [counts, setCounts] = useState({employees: 0, departments: 0, leaves: 0});
  const [error, setError] = useState("");
  useEffect(() => {
    Promise.all([API.get("employees/"), API.get("departments/"), API.get("leaves/")])
      .then(([e, d, l]) => setCounts({employees: e.data.length, departments: d.data.length, leaves: l.data.filter(x => x.status === "PENDING").length}))
      .catch(() => setError("Could not load data. Check that Django and MySQL are running."));
  }, []);
  return <div>
    <h2 className="mb-4">Dashboard</h2>
    {error && <div className="alert alert-warning">{error}</div>}
    <div className="row g-3">
      {[["Total Employees", counts.employees], ["Departments", counts.departments], ["Pending Leaves", counts.leaves]].map(([label, value]) =>
        <div className="col-md-4" key={label}><div className="card stat-card p-4"><div className="text-secondary">{label}</div><div className="display-5 fw-bold">{value}</div></div></div>
      )}
    </div>
    <div className="panel mt-4"><h5>Welcome to HRMS</h5><p className="text-secondary mb-0">Use the left menu to manage employee and HR records.</p></div>
  </div>;
}
