import { useEffect, useState } from "react";
import API from "../services/api";

const empty = {name:"", email:"", phone:"", department:"", designation:"", salary:"", joining_date:""};

export default function Employees() {
  const [rows, setRows] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState(null);
  const [message, setMessage] = useState("");

  async function load() {
    try {
      const [e, d] = await Promise.all([API.get("employees/"), API.get("departments/")]);
      setRows(e.data); setDepartments(d.data);
    } catch { setMessage("Unable to load data. Check backend/database."); }
  }
  useEffect(() => { load(); }, []);
  function change(e) { setForm({...form, [e.target.name]: e.target.value}); }

  async function submit(e) {
    e.preventDefault();
    const payload = {...form, department: form.department ? Number(form.department) : null, salary: Number(form.salary)};
    try {
      if (editing) await API.put(`employees/${editing}/`, payload);
      else await API.post("employees/", payload);
      setForm(empty); setEditing(null); setMessage("Saved successfully."); load();
    } catch (err) { setMessage(JSON.stringify(err.response?.data || "Save failed")); }
  }
  function edit(row) {
    setEditing(row.id);
    setForm({name:row.name, email:row.email, phone:row.phone, department:row.department || "", designation:row.designation, salary:row.salary, joining_date:row.joining_date});
    window.scrollTo({top:0, behavior:"smooth"});
  }
  async function remove(id) {
    if (!window.confirm("Delete this employee?")) return;
    try { await API.delete(`employees/${id}/`); setMessage("Employee deleted."); load(); }
    catch { setMessage("Delete failed."); }
  }
  return <div>
    <div className="d-flex justify-content-between align-items-center mb-3"><h2>Employees</h2><span className="badge text-bg-primary">{rows.length} records</span></div>
    {message && <div className="alert alert-info">{message}</div>}
    <form className="panel mb-4" onSubmit={submit}>
      <h5>{editing ? "Edit Employee" : "Add Employee"}</h5>
      <div className="row g-2">
        {[
          ["name","Full name","text"],["email","Email","email"],["phone","Phone","text"],
          ["designation","Designation","text"],["salary","Salary","number"],["joining_date","Joining date","date"]
        ].map(([name, placeholder, type]) => <div className="col-md-4" key={name}><input className="form-control" name={name} type={type} placeholder={placeholder} value={form[name]} onChange={change} required /></div>)}
        <div className="col-md-4"><select className="form-select" name="department" value={form.department} onChange={change}><option value="">Select department (optional)</option>{departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}</select></div>
      </div>
      <div className="mt-3 d-flex gap-2"><button className="btn btn-primary">{editing ? "Update" : "Add"} Employee</button>{editing && <button type="button" className="btn btn-outline-secondary" onClick={()=>{setEditing(null);setForm(empty);}}>Cancel</button>}</div>
    </form>
    <div className="panel table-responsive"><table className="table table-hover align-middle mb-0">
      <thead><tr><th>Name</th><th>Email</th><th>Department</th><th>Designation</th><th>Salary</th><th>Actions</th></tr></thead>
      <tbody>{rows.map(r=><tr key={r.id}><td>{r.name}</td><td>{r.email}</td><td>{r.department_name || "-"}</td><td>{r.designation}</td><td>{r.salary}</td><td><button className="btn btn-sm btn-outline-primary me-2" onClick={()=>edit(r)}>Edit</button><button className="btn btn-sm btn-outline-danger" onClick={()=>remove(r.id)}>Delete</button></td></tr>)}</tbody>
    </table></div>
  </div>;
}
